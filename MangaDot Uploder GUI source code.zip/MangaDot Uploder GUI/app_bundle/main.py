"""MangaDot Uploader - GUI entry point."""
import sys
import time
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, QThread, QObject, Signal
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QStackedWidget, QMessageBox, QWidget,
    QVBoxLayout, QFileDialog
)

from mangadot_app.gui import theme
from mangadot_app.gui import thread_is_running
from mangadot_app.gui.widgets import StepStrip, ProfileLoginPage
from mangadot_app.gui.picker_screen import PickerScreen
from mangadot_app.gui.subset_picker_screen import SubsetPickerScreen
from mangadot_app.gui.login_screen import LoginScreen
from mangadot_app.gui.group_config_dialog import GroupConfigScreen
from mangadot_app.gui.title_review_screen import TitleReviewScreen
from mangadot_app.gui.upload_progress_screen import UploadProgressScreen
from mangadot_app.gui.settings_dialog import StartupSettingsDialog
from mangadot_app.gui.optimizer_progress_screen import OptimizerProgressScreen
from mangadot_app.gui.summary_screen import SummaryScreen
from mangadot_app import parser as parser_mod
from mangadot_app import debugging
from mangadot_app import config as config_mod
from mangadot_app import net

_ASSETS_DIR = Path(__file__).resolve().parent / "mangadot_app" / "assets"
_LOGO_PATH = _ASSETS_DIR / "mangadotnet-purple.svg"

_STEP_LOGIN = 0
_STEP_MANGA = 1
_STEP_ATTRIBUTION = 2
_STEP_REVIEW = 3
_STEP_UPLOAD = 4
_STEP_DONE = 5

# ==============================================================================
# 🧠 WORKERS & GUI LOGIC
# ==============================================================================

class _ProfileFetchWorker(QObject):
    finished = Signal(object)  
    def __init__(self, session, username=None):
        super().__init__()
        self.session = session
        self.username = username

    def run(self):
        profile = net.fetch_profile_stats(self.session, username=self.username)
        self.finished.emit(profile)


class _SummaryDetailsWorker(QObject):
    finished = Signal(object, object, dict)

    def __init__(self, session, manga_id, upload_type, user_id):
        super().__init__()
        self.session = session
        self.manga_id = manga_id
        self.upload_type = upload_type
        self.user_id = user_id

    def run(self):
        details = net.fetch_manga_full_details(self.manga_id, self.session)
        
        cover_bytes = None
        if details and details.get("cover_url"):
            cover_bytes = net.fetch_image_bytes(self.session, details["cover_url"])

        chapter_map = net.build_uploaded_chapter_map(
            self.session, self.manga_id, self.upload_type, self.user_id
        )

        self.finished.emit(details, cover_bytes, chapter_map)


class MainWindow(QMainWindow):
    def __init__(self, settings):
        super().__init__()
        self.setWindowTitle("MangaDot Uploader")
        self.resize(1172, 602)  

        self.settings = settings
        self.session = None
        self.username = None
        self.user_id = None
        self.upload_progress_screen = None
        self.group_config_screen = None
        self.picker_screen = None
        self.optimizer_screen = None
        self.subset_picker_screen = None
        self.summary_screen = None
        self.title_review_screen = None
        self.login_screen = None
        self.profile_card = None
        self._chapter_map = {}
        self._profile_thread = None
        self._profile_worker = None
        self._summary_thread = None
        self._summary_worker = None
        self._target_key = None
        self._last_per_file_group_map = {}
        self._last_per_file_scanlator_map = {}
        self._manga_title = None

        # Determine mode
        self._is_dry_run = getattr(self.settings, "launch_mode", "normal") == "dry_run"

        central = QWidget()
        outer_layout = QVBoxLayout(central)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.setSpacing(0)

        self.step_strip = StepStrip()
        outer_layout.addWidget(self.step_strip)

        self.stack = QStackedWidget()
        outer_layout.addWidget(self.stack, 1)
        self.setCentralWidget(central)

        if self._is_dry_run:
            self._show_step_strip = True
            self.step_strip.setVisible(True)
            self.session = net.create_base_session(
                self.settings.proxy_url, 
                self.settings.proxy_no_verify, 
                self.settings.debug_enabled
            )
            self.username = "Dry Run User"
            self.user_id = "0"
            self._advance_to_manga_picker()
            
        elif self.settings.opt_mode == "standalone":
            self._show_step_strip = False
            self.step_strip.setVisible(False)
            self._start_standalone_optimizer()
        else:
            self._show_step_strip = True
            self.step_strip.setVisible(True)
            self._start_login()

    _TRACKED_SCREEN_ATTRS = (
        "login_screen", "upload_progress_screen", "group_config_screen",
        "picker_screen", "optimizer_screen", "subset_picker_screen",
        "summary_screen", "title_review_screen", "profile_card",
    )

    def _teardown_screens(self, remove_from_stack=False):
        """Stops every tracked screen's background work (and the two
        module-level fetch threads), optionally also removing each
        screen from self.stack and scheduling it for deletion.

        Used by both closeEvent (remove_from_stack=False - the process is
        exiting anyway, no need to touch the stack) and
        _restart_from_settings (remove_from_stack=True - previously that
        method deleted every screen via deleteLater() without ever
        calling stop_background_work() first, so a live upload/optimizer
        thread with signal connections back into its (now being deleted)
        screen could later try to deliver a signal to a partially/fully
        deleted QObject).

        profile_card is included here even though it isn't one of the
        *_screen attributes and lives outside the QStackedWidget as an
        alias for the ProfileLoginPage's banner (self.profile_page.banner)
        - it has its own background thread (avatar/cover fetch) via
        ProfileBannerWidget.stop_background_work() and was previously
        never told to stop at all.
        """
        for screen_attr in self._TRACKED_SCREEN_ATTRS:
            screen = getattr(self, screen_attr, None)
            if screen is not None and hasattr(screen, "stop_background_work"):
                screen.stop_background_work()

        if self._profile_thread is not None and thread_is_running(self._profile_thread):
            self._profile_thread.quit()
            self._profile_thread.wait(3000)
        if self._summary_thread is not None and thread_is_running(self._summary_thread):
            self._summary_thread.quit()
            self._summary_thread.wait(3000)

        if remove_from_stack:
            while self.stack.count() > 0:
                widget = self.stack.widget(0)
                self.stack.removeWidget(widget)
                widget.deleteLater()

    def closeEvent(self, event):
        self._teardown_screens(remove_from_stack=False)
        super().closeEvent(event)

    def _set_step(self, index):
        if self._show_step_strip:
            self.step_strip.set_current(index)

    def _show(self, widget):
        if self.stack.indexOf(widget) == -1:
            self.stack.addWidget(widget)
        self.stack.setCurrentWidget(widget)

    def _restart_from_settings(self):
        settings = StartupSettingsDialog()
        self.hide()
        
        if settings.exec():
            self.settings = settings
            self._is_dry_run = getattr(self.settings, "launch_mode", "normal") == "dry_run"
            
            if settings.debug_enabled:
                debugging.enable_debug_logging()
                
            self._teardown_screens(remove_from_stack=True)
                
            self.upload_progress_screen = None
            self.group_config_screen = None
            self.picker_screen = None
            self.optimizer_screen = None
            self.subset_picker_screen = None
            self.summary_screen = None
            self.title_review_screen = None
            self.login_screen = None
            self.profile_card = None

            if self._is_dry_run:
                self._show_step_strip = True
                self.step_strip.setVisible(True)
                self.session = net.create_base_session(
                    self.settings.proxy_url, 
                    self.settings.proxy_no_verify, 
                    self.settings.debug_enabled
                )
                self.username = "Dry Run User"
                self.user_id = "0"
                self._advance_to_manga_picker()
            elif self.settings.opt_mode == "standalone":
                self._show_step_strip = False
                self.step_strip.setVisible(False)
                self._start_standalone_optimizer()
            else:
                self._show_step_strip = True
                self.step_strip.setVisible(True)
                self._start_login()
                
            self.show()
        else:
            self.close()

    # ------------------------------------------------------ standalone optimizer
    def _start_standalone_optimizer(self):
        cfg = config_mod.load_config()
        start_dir = cfg.get("library", "")
        directory = QFileDialog.getExistingDirectory(self, "Select Folder to Optimize", start_dir)

        if not directory:
            self.close()
            return

        config_mod.remember_library(directory)
        self.optimizer_screen = OptimizerProgressScreen(directory, self.settings)
        if getattr(self.optimizer_screen, "_declined", False):
            self._start_standalone_optimizer()
            return
        self.optimizer_screen.optimization_finished.connect(lambda _: self.close())
        self._show(self.optimizer_screen)

    # -------------------------------------------------------------------- login
    def _start_login(self):
        self._set_step(_STEP_LOGIN)
        self.login_placeholder = QWidget()
        self._show(self.login_placeholder)

        self.login_screen = LoginScreen(
            parent=self,
            proxy_url=self.settings.proxy_url,
            proxy_no_verify=self.settings.proxy_no_verify,
            debug_enabled=self.settings.debug_enabled
        )
        self.login_screen.login_succeeded.connect(self._on_login_succeeded)
        self.login_screen.content_resized.connect(
            lambda: self._position_popup_centered(self.login_screen)
        )
        QTimer.singleShot(50, self._show_login_popup)

    def _show_login_popup(self):
        self._position_popup_centered(self.login_screen)
        self.login_screen.show()
        QTimer.singleShot(150, lambda: self._position_popup_centered(self.login_screen))

    def _position_popup_centered(self, dialog):
        if hasattr(dialog, "_resize_to_content"):
            dialog._resize_to_content()
        else:
            dialog.adjustSize()
        main_geo = self.geometry()
        x = main_geo.x() + (main_geo.width() - dialog.width()) // 2
        y = main_geo.y() + (main_geo.height() - dialog.height()) // 2
        dialog.move(max(x, 0), max(y, 0))

    def _on_login_succeeded(self, username, user_id, session):
        self.username = username
        self.user_id = user_id
        self.session = session

        if hasattr(self.login_screen, "stop_background_work"):
            self.login_screen.stop_background_work()
        self.login_screen.close()

        if self._offer_resume_if_paused():
            return

        winner = getattr(self.login_screen, "_winner", None)
        browser_name = winner["browser"].title() if winner else ""

        self.profile_page = ProfileLoginPage(
            logo_path=_LOGO_PATH,
            username=username,
            browser_name=browser_name,
            session=session,
        )
        self.profile_card = self.profile_page.banner  # kept for _on_profile_fetched below
        self.profile_page.continue_clicked.connect(self._advance_to_manga_picker)
        self._show(self.profile_page)

        self._profile_thread = QThread()
        self._profile_worker = _ProfileFetchWorker(session, username=username)
        self._profile_worker.moveToThread(self._profile_thread)
        self._profile_thread.started.connect(self._profile_worker.run)
        self._profile_worker.finished.connect(self._on_profile_fetched)
        self._profile_worker.finished.connect(self._profile_thread.quit)
        self._profile_worker.finished.connect(self._profile_worker.deleteLater)
        self._profile_thread.finished.connect(self._profile_thread.deleteLater)
        self._profile_thread.start()

    def _on_profile_fetched(self, profile):
        if profile:
            self.profile_card.set_profile(profile)
        else:
            self.profile_card.set_fetch_failed()

    def _offer_resume_if_paused(self):
        """Returns True if a paused upload was found AND the user chose
        to resume it (in which case the caller should skip building the
        normal post-login flow - this method already showed the resumed
        UploadProgressScreen itself). Returns False if there was nothing
        paused, or the user chose to discard it - either way, the normal
        flow should proceed as if nothing happened."""
        paused_state = config_mod.load_paused_upload()
        if paused_state is None:
            return False

        bc = paused_state.get("batch_config", {})
        files = paused_state.get("files", [])
        paused_at = paused_state.get("paused_at")
        age_str = self._format_paused_age(paused_at) if paused_at else "an unknown time ago"

        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Question)
        msg.setWindowTitle("Resume paused upload?")
        msg.setText(
            f"You have a paused upload from {age_str} "
            f"({len(files)} file(s) remaining, manga ID {bc.get('manga_id', '?')}).\n\n"
            f"Resume it now, or discard it and start fresh?"
        )
        resume_btn = msg.addButton("Resume upload", QMessageBox.YesRole)
        msg.addButton("Discard and start fresh", QMessageBox.NoRole)
        msg.setDefaultButton(resume_btn)
        msg.exec()

        if msg.clickedButton() != resume_btn:
            config_mod.clear_paused_upload()
            return False

        bc = paused_state["batch_config"]
        self._manga_id = bc["manga_id"]
        # Paused-upload state never persisted the manga title (only its
        # id), so there's nothing to show here without an extra network
        # fetch - UploadProgressScreen/SummaryScreen just fall back to
        # the manga_id-only label in this one path.
        self._manga_title = None
        self._upload_type = bc["upload_type"]
        self._lang = bc.get("language")
        self._group_label = "Resumed upload"
        self._group_config = {
            "is_group_upload": bc.get("is_group_upload"),
            "group_ids": bc.get("group_ids") or [],
            "scanlator_name": bc.get("scanlator_name"),
            "per_file_group_map": bc.get("per_file_group_map"),
        }
        self._last_per_file_group_map = bc.get("per_file_group_map") or {}
        self._last_per_file_scanlator_map = bc.get("per_file_scanlator_map") or {}
        self._target_key = config_mod.make_target_key(
            self._manga_id, self._upload_type, self._lang,
            self._group_config["group_ids"], self._group_config["scanlator_name"],
        )
        # _on_upload_finished normally reads all_files from
        # self.title_review_screen.files - which is None on this path,
        # since resuming skips that screen entirely. Standing in a
        # lightweight object with just the attribute it actually reads
        # avoids needing a parallel copy of _on_upload_finished's logic
        # just for the resume case.
        class _ResumedFilesStandIn:
            """Not a QObject - deliberately. This only exists to satisfy
            _on_upload_finished's getattr(self.title_review_screen,
            "files", []) read, since the resume path skips the real
            TitleReviewScreen entirely. deleteLater() is a no-op stub
            (not the real QObject deferred-deletion mechanism) because
            _cleanup_previous_upload_cycle() and _teardown_screens()
            unconditionally call it on every tracked screen attribute,
            including this one - without this stub, starting a second
            upload cycle (e.g. "Upload Again") after a resumed session
            would raise AttributeError."""
            def __init__(self, files):
                self.files = files
            def deleteLater(self):
                pass
        self.title_review_screen = _ResumedFilesStandIn(paused_state["files"])

        self._show_step_strip = True
        self.step_strip.setVisible(True)
        self._set_step(_STEP_UPLOAD)
        self.upload_progress_screen = UploadProgressScreen.for_resume(paused_state, self.session)
        self.upload_progress_screen.upload_finished.connect(self._on_upload_finished)
        self._show(self.upload_progress_screen)
        return True

    @staticmethod
    def _format_paused_age(paused_at):
        seconds = max(0, time.time() - paused_at)
        if seconds < 60:
            return "less than a minute ago"
        minutes = int(seconds // 60)
        if minutes < 60:
            return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
        hours = int(minutes // 60)
        if hours < 24:
            return f"{hours} hour{'s' if hours != 1 else ''} ago"
        days = int(hours // 24)
        return f"{days} day{'s' if days != 1 else ''} ago"

    def _advance_to_manga_picker(self):
        self._cleanup_previous_upload_cycle()
        self._set_step(_STEP_MANGA)
        self.picker_screen = PickerScreen(session=self.session)
        self.picker_screen.picker_finished.connect(self._on_picker_finished)
        self._show(self.picker_screen)

    def _cleanup_previous_upload_cycle(self):
        """Removes and deletes screens left over from a completed upload
        cycle when starting a new one (via "Upload Again" or the initial
        post-login advance). Safe to do here specifically: once a fresh
        picker_screen is about to start the flow over, nothing can still
        need to navigate "back" into the previous cycle's
        group_config_screen / subset_picker_screen / title_review_screen
        / upload_progress_screen / optimizer_screen, or into the outgoing
        picker_screen itself. Those same screens are deliberately left
        alone by mid-flow back_requested handlers, where a user going
        "back" genuinely does need the previous screen instance to still
        be alive (e.g. group_config_screen.back_requested reshows
        self.picker_screen)."""
        cycle_attrs = (
            "picker_screen", "group_config_screen", "subset_picker_screen",
            "title_review_screen", "upload_progress_screen", "optimizer_screen",
            "summary_screen",
        )
        for attr in cycle_attrs:
            screen = getattr(self, attr, None)
            if screen is None:
                continue
            if hasattr(screen, "stop_background_work"):
                screen.stop_background_work()
            if isinstance(screen, QWidget) and self.stack.indexOf(screen) != -1:
                self.stack.removeWidget(screen)
            screen.deleteLater()
            setattr(self, attr, None)

    # ------------------------------------------------------------------ picker
    def _on_picker_finished(self, folder, manga_id, manga_title, lang, threads, upload_type,
                             chapter_naming, custom_regex, strip_groups, verify_timeout):
        self._folder = folder
        self._manga_id = manga_id
        self._manga_title = manga_title or None
        self._lang = lang
        self._threads = threads
        self._upload_type = upload_type
        self._chapter_naming = chapter_naming or "extract"
        self._custom_regex = custom_regex or None
        self._advanced_strip = strip_groups
        self._verify_timeout = verify_timeout

        self.session.headers.update({"Referer": f"https://mangadot.net/manga/{manga_id}/upload"})

        self._set_step(_STEP_ATTRIBUTION)
        self.group_config_screen = GroupConfigScreen(self.session, folder, upload_type=self._upload_type)
        self.group_config_screen.config_finished.connect(self._on_group_config_finished)
        self.group_config_screen.back_requested.connect(
            lambda: (self._set_step(_STEP_MANGA), self._show(self.picker_screen))
        )
        self._show(self.group_config_screen)

    def _on_group_config_finished(self, group_config):
        self._group_config = group_config
        self._group_label = group_config.get("group_name", "-")

        if self.settings.opt_mode == "chained" and not self._is_dry_run:
            self.optimizer_screen = OptimizerProgressScreen(self._folder, self.settings)
            if getattr(self.optimizer_screen, "_declined", False):
                self._show(self.group_config_screen)
                return
            self.optimizer_screen.optimization_finished.connect(self._on_optimization_finished)
            self._show(self.optimizer_screen)
        else:
            self._scan_and_pick_subset()

    def _on_optimization_finished(self, new_folder):
        self._folder = new_folder
        self._scan_and_pick_subset()

    # ------------------------------------------------------------------ scan
    def _scan_and_pick_subset(self):
        custom_renames, custom_extractor = parser_mod.parse_custom_regex_input(self._custom_regex)

        files, errors = parser_mod.scan_directory_files(
            self._folder,
            upload_type=self._upload_type,
            chapter_naming=self._chapter_naming,
            custom_regex=custom_extractor,
            custom_renames=custom_renames,
            strip_groups=self._group_config.get("strip_bracket_groups", False) or self._advanced_strip,
        )

        if errors:
            QMessageBox.warning(self, "Some files were skipped", "\n".join(errors[:10]))
        if not files:
            QMessageBox.critical(self, "No files found", f"No {self._upload_type} archives (.cbz/.zip) found in:\n{self._folder}")
            return

        if self._upload_type == "chapter":
            drift = parser_mod.detect_episode_drift(files)
            if drift:
                msg = QMessageBox(self)
                msg.setWindowTitle("Numbering Conflict Detected")
                msg.setText(
                    "Filename sequence and Episode labels disagree "
                    "(this can happen after a season reset or inserted specials).\n\n"
                    f"{len(drift['conflicts'])} file(s) affected.\n"
                    f"Example: '{drift['example_filename']}'\n"
                    f" -> File Index: {drift['example_file_index']:g}\n"
                    f" -> Episode Label: {drift['example_episode_label']:g}\n\n"
                    "How should these be sorted on MangaDot?"
                )
                cont_btn = msg.addButton(f"Continuous (Use Ch {drift['example_file_index']:g})", QMessageBox.AcceptRole)
                reset_btn = msg.addButton(f"Trust Labels (Use Ch {drift['example_episode_label']:g})", QMessageBox.AcceptRole)
                msg.exec()

                mode = "continuous" if msg.clickedButton() == cont_btn else "reset"
                parser_mod.apply_episode_drift_correction(files, mode)
                files.sort(key=lambda x: x["number"])

        approved_tags = self._group_config.get("approved_tags")
        if approved_tags is not None:
            parser_mod.apply_tag_filter_to_files(files, approved_tags)

        parser_mod.finalize_file_entries(files)

        # --- SMART DB SKIPPING LOGIC ---
        self._target_key = config_mod.make_target_key(
            self._manga_id, self._upload_type, self._lang,
            self._group_config.get("group_ids") or [],
            self._group_config.get("scanlator_name")
        )

        already_uploaded = config_mod.db_uploaded_numbers(self._target_key)
        if already_uploaded:
            skip_candidates = [f for f in files if config_mod._chapter_number_key(f["number"]) in already_uploaded]
            if skip_candidates:
                msg = QMessageBox(self)
                msg.setWindowTitle("Already Uploaded")
                msg.setText(
                    f"{len(skip_candidates)} file(s) match numbers already recorded as uploaded to "
                    "this exact target (manga/type/language/group) from a previous run.\n\n"
                    "Do you want to skip them?"
                )
                yes_btn = msg.addButton("Skip already uploaded", QMessageBox.YesRole)
                msg.addButton("Keep all", QMessageBox.NoRole)
                msg.exec()

                if msg.clickedButton() == yes_btn:
                    skip_names = {f["filename"] for f in skip_candidates}
                    files = [f for f in files if f["filename"] not in skip_names]
                    if not files:
                        QMessageBox.information(self, "Nothing left", "All files in this batch were already recorded as uploaded.")
                        self._show(self.group_config_screen)
                        return
        # --- END DB LOGIC ---

        self._scanned_files = files

        if len(files) <= 3:
            self._load_title_review(files)
            return

        self.subset_picker_screen = SubsetPickerScreen(files, upload_type=self._upload_type)
        self.subset_picker_screen.selection_finished.connect(self._load_title_review)
        self.subset_picker_screen.back_requested.connect(
            lambda: self._show(self.group_config_screen)
        )
        self._show(self.subset_picker_screen)

    def _load_title_review(self, files):
        self._set_step(_STEP_REVIEW)
        self.title_review_screen = TitleReviewScreen(
            files, upload_type=self._upload_type, group_label=self._group_label, session=self.session,
            preview_only=self._is_dry_run
        )
        self.title_review_screen.review_finished.connect(self._on_review_finished)
        self.title_review_screen.back_requested.connect(self._back_to_subset_or_group)
        self._show(self.title_review_screen)

    def _back_to_subset_or_group(self):
        if self.subset_picker_screen is not None:
            self._show(self.subset_picker_screen)
        else:
            self._show(self.group_config_screen)

    def _on_review_finished(self, files):
        if self._is_dry_run:
            QMessageBox.information(self, "Dry Run Complete", "Dry run finished successfully. No files were uploaded.")
            self._restart_from_settings()
            return

        gc = self._group_config
        self._set_step(_STEP_UPLOAD)

        per_file_group_map, per_file_scanlator_map = parser_mod.build_upload_routing_maps(
            files, gc.get("per_file_group_map")
        )
        self._last_per_file_group_map = per_file_group_map
        self._last_per_file_scanlator_map = per_file_scanlator_map

        self.upload_progress_screen = UploadProgressScreen(
            files, self.session, self._manga_id, gc.get("group_ids") or [], self._upload_type,
            self._lang, gc.get("scanlator_name"), self._threads,
            per_file_group_map=per_file_group_map,
            verify_timeout=self._verify_timeout,
            current_user_id=self.user_id,
            is_group_upload=gc.get("is_group_upload"),
            per_file_scanlator_map=per_file_scanlator_map,
            manga_title=self._manga_title,
        )
        self.upload_progress_screen.upload_finished.connect(self._on_upload_finished)
        self.upload_progress_screen.back_requested.connect(self._on_upload_back_requested)
        self._show(self.upload_progress_screen)

    def _on_upload_back_requested(self):
        self._set_step(_STEP_REVIEW)
        # title_review_screen is always set by this point - it's the only
        # path that leads into the upload screen - so this is the normal
        # case. The elif/else are defensive fallbacks only.
        if self.title_review_screen is not None:
            self._show(self.title_review_screen)
        elif self.subset_picker_screen is not None:
            self._show(self.subset_picker_screen)
        else:
            self._show(self.group_config_screen)

    def _on_upload_finished(self, failed_set, elapsed):
        self._set_step(_STEP_DONE)
        all_files = getattr(self.title_review_screen, "files", [])
        
        # --- NEW DB LOGIC: Record successful uploads ---
        uploaded_files = [f for f in all_files if f["filename"] not in failed_set]
        if uploaded_files and self._target_key is not None:
            config_mod.db_record_uploaded(self._target_key, uploaded_files)
        # --- END DB LOGIC ---
        
        # 1. Initialize the UI strictly with data (no network session passed)
        self.summary_screen = SummaryScreen(
            self._manga_id, self._upload_type, self.username,
            self._group_label, all_files, failed_set, elapsed,
            per_file_group_map=self._last_per_file_group_map,
            per_file_scanlator_map=self._last_per_file_scanlator_map,
            is_group_upload=self._group_config.get("is_group_upload"),
            batch_group_ids=self._group_config.get("group_ids") or [],
        )
        self.summary_screen.done_requested.connect(self.close)
        self.summary_screen.upload_again_requested.connect(self._advance_to_manga_picker)
        self._show(self.summary_screen)

        # 2. Spin up the backend worker natively in the orchestrator
        self._summary_thread = QThread()
        self._summary_worker = _SummaryDetailsWorker(
            self.session, self._manga_id, self._upload_type, self.user_id
        )
        self._summary_worker.moveToThread(self._summary_thread)
        self._summary_thread.started.connect(self._summary_worker.run)
        
        # 3. Pipe the background data directly to the UI when it's done
        self._summary_worker.finished.connect(self.summary_screen.set_details)
        self._summary_worker.finished.connect(self._summary_thread.quit)
        self._summary_worker.finished.connect(self._summary_worker.deleteLater)
        self._summary_thread.finished.connect(self._summary_thread.deleteLater)
        self._summary_thread.start()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("MangaDot Uploader")
    
    from PySide6.QtGui import QIcon
    icon_path = Path(__file__).resolve().parent / "mangadot_app" / "assets" / "favicon.ico"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    app.setStyle("Fusion")
    app.setPalette(theme.dark_palette())
    app.setFont(theme.base_font())
    app.setStyleSheet(theme.stylesheet())

    settings = StartupSettingsDialog()
    if settings.exec():
        if settings.debug_enabled:
            debugging.enable_debug_logging()

        window = MainWindow(settings)
        window.show()
        sys.exit(app.exec())


if __name__ == "__main__":
    main()