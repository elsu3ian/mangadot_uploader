"""Group/scanlator attribution"""
import os

from PySide6.QtCore import Qt, Signal, QObject
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit,
    QRadioButton, QButtonGroup, QListWidget, QListWidgetItem, QStackedWidget,
    QMessageBox, QSizePolicy
)

from .. import parser as parser_mod
from .. import net
from . import thread_is_running, workers
from .widgets import Card, heading, section_label, hint_label, make_primary, make_flat_link, GlassBox
from .theme import Color


def _search_group_queries(session, text):
    """Try each candidate query for `text` against the group search API,
    stopping at the first query that returns results. Shared by both the
    auto-detection and manual-search workers below."""
    results = []
    matched_query = None
    for q in parser_mod.group_search_queries(text):
        results = net.search_groups(q, session)
        if results:
            matched_query = q
            break
    return results, matched_query


class _GroupSearchWorker(QObject):
    finished = Signal(str, list, object)

    def __init__(self, session, name):
        super().__init__()
        self.session = session
        self.name = name

    def run(self):
        results, matched_query = _search_group_queries(self.session, self.name)
        self.finished.emit(self.name, results, matched_query)


class _ManualSearchWorker(QObject):
    finished = Signal(str, list)

    def __init__(self, session, query):
        super().__init__()
        self.session = session
        self.query = query

    def run(self):
        results, _matched_query = _search_group_queries(self.session, self.query)
        self.finished.emit(self.query, results)


class GroupConfigScreen(QWidget):
    config_finished = Signal(dict)
    back_requested = Signal()

    def __init__(self, session, directory, upload_type="chapter", parent=None):
        super().__init__(parent)
        self.session = session
        self.directory = directory
        self.upload_type = upload_type

        self._threads = []
        self._workers = [] 
        self._name_to_group = {}
        self._per_file_names = {}
        self._per_file_group_map_result = {}
        self._pending_resolutions = 0
        self._resolved_group_ids = []
        self._resolved_group_name = None
        self._strip_bracket_groups = False
        self._detected_names = []
        self._active_target_name = None
        self._auto_candidates = {}

        self._build_ui()
        self._detect_groups()

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(28, 20, 28, 24)
        outer.setSpacing(16)

        outer.addWidget(heading("Credit this upload", "Attribute the chapters to a scan group, or upload under your own name."))

        mode_card = Card()
        mode_row = QHBoxLayout()
        mode_row.setSpacing(16)
        self.group_radio = QRadioButton("Upload as a group")
        self.individual_radio = QRadioButton("Upload as an individual scanlator")
        self.group_radio.setChecked(True)
        mode_group = QButtonGroup(self)
        mode_group.addButton(self.group_radio)
        mode_group.addButton(self.individual_radio)
        self.group_radio.toggled.connect(self._on_mode_changed)
        mode_row.addWidget(self.group_radio)
        mode_row.addWidget(self.individual_radio)
        mode_row.addStretch(1)
        mode_card.addLayout(mode_row)
        outer.addWidget(mode_card)

        self.page_stack = QStackedWidget()
        outer.addWidget(self.page_stack, 1)

        group_page = Card()

        self.detection_label = hint_label("Scanning filenames for group tags\u2026")
        group_page.addWidget(self.detection_label)

        self.detected_list = QListWidget()
        self.detected_list.setMaximumHeight(90)
        self.detected_list.setStyleSheet(
            f"QListWidget {{ background-color: {Color.BG_APP}; "
            f"border: 1px solid {Color.BORDER}; border-radius: 9px; }}"
            f"QListWidget::item {{ padding: 3px 6px; }}"
            f"QListWidget::item:hover {{ background-color: {Color.ACCENT_SOFT}; }}"
        )
        self.detected_list.itemClicked.connect(self._on_detected_name_clicked)
        group_page.addWidget(self.detected_list)

        self.search_target_label = QLabel("")
        self.search_target_label.setWordWrap(True)
        self.search_target_label.setProperty("role", "muted")
        group_page.addWidget(self.search_target_label)

        group_page.addWidget(section_label("Search MangaDot's group directory"))
        search_row = QHBoxLayout()
        search_row.setSpacing(8)
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search group by name, or enter numeric ID directly")
        self.search_input.returnPressed.connect(self._on_manual_search)
        self.search_input.setStyleSheet(
            f"QLineEdit {{ background-color: {Color.BG_APP}; "
            f"border: 1px solid {Color.ACCENT_SOFT_BORDER}; border-radius: 6px; padding: 6px 8px; }}"
            f"QLineEdit:focus {{ border: 1px solid {Color.ACCENT}; }}"
        )
        self.search_button = make_flat_link(QPushButton("Search"), color=Color.ACCENT, hover_color=Color.ACCENT_HOVER, bold=True)
        self.search_button.clicked.connect(self._on_manual_search)
        search_button_box = GlassBox(
            tint_rgba="rgba(92, 225, 230, 18)",
            border_color=Color.ACCENT_SOFT_BORDER,
        )
        search_button_box.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        search_button_box_layout = QHBoxLayout(search_button_box)
        search_button_box_layout.setContentsMargins(16, 4, 16, 4)
        search_button_box_layout.addWidget(self.search_button)
        search_row.addWidget(self.search_input, 1)
        search_row.addWidget(search_button_box)
        group_page.addLayout(search_row)

        self.search_results_list = QListWidget()
        self.search_results_list.itemDoubleClicked.connect(self._on_search_result_picked)
        self.search_results_list.setStyleSheet(
            f"QListWidget {{ background-color: {Color.BG_APP}; "
            f"border: 1px solid {Color.BORDER}; border-radius: 9px; }}"
        )
        group_page.addWidget(self.search_results_list)

        self.selected_group_label = QLabel("No group selected yet.")
        self.selected_group_label.setWordWrap(True)
        self.selected_group_label.setProperty("role", "muted")
        group_page.addWidget(self.selected_group_label)

        self.page_stack.addWidget(group_page)

        individual_page = Card()
        individual_page.addWidget(section_label("Scanlator credit"))
        individual_page.addWidget(hint_label("Shown publicly as the uploader credit on every chapter."))
        self.scanlator_input = QLineEdit()
        self.scanlator_input.setPlaceholderText("Your scanlator / uploader name")
        individual_page.addWidget(self.scanlator_input)
        individual_page.layout().addStretch(1)
        self.page_stack.addWidget(individual_page)

        bottom_row = QHBoxLayout()
        self.back_button = QPushButton("Back")
        self.back_button.clicked.connect(self.back_requested.emit)
        bottom_row.addWidget(self.back_button)
        bottom_row.addStretch(1)
        continue_box = GlassBox(
            tint_rgba="rgba(92, 225, 230, 18)",
            border_color=Color.ACCENT_SOFT_BORDER,
        )
        continue_box_layout = QHBoxLayout(continue_box)
        continue_box_layout.setContentsMargins(14, 6, 14, 6)
        self.continue_button = make_flat_link(QPushButton("Continue"), bold=True)
        self.continue_button.clicked.connect(self._on_continue)
        continue_box_layout.addWidget(self.continue_button)
        bottom_row.addWidget(continue_box)
        outer.addLayout(bottom_row)

    def _mark_group_selected(self, name):
        self.selected_group_label.setText(f"\u2705 Selected group: {name}")
        self.selected_group_label.setProperty("role", "success")
        self.selected_group_label.style().unpolish(self.selected_group_label)
        self.selected_group_label.style().polish(self.selected_group_label)

    def _on_mode_changed(self, checked):
        self.page_stack.setCurrentIndex(0 if self.group_radio.isChecked() else 1)

    def _detect_groups(self):
        names, per_file = parser_mod.detect_groups_from_filenames(self.directory, self.upload_type)
        self._per_file_names = per_file
        self._detected_names = list(names)

        if not names:
            self.detection_label.setText(
                "No group tags detected in filenames. Search for your group below, "
                "or switch to individual scanlator mode."
            )
            return

        is_mixed = parser_mod.is_groups_mixed(per_file)
        if is_mixed:
            unique_sets = parser_mod.distinct_group_sets(per_file)
            lines = ["Detected mixed groups across chapters:"]
            for gnames in unique_sets:
                lines.append("  • " + "  +  ".join(sorted(gnames)))
            self.detection_label.setText("\n".join(lines))
        else:
            self.detection_label.setText(f"Detected group(s) from filenames: {', '.join(names)}  (resolving…)")

        for name in names:
            item = QListWidgetItem()
            item.setData(Qt.UserRole, name)
            self.detected_list.addItem(item)
            self._refresh_detected_list_item(name)

        self._update_search_target_label()

        self._pending_resolutions = len(names)
        workers.prune_finished(self._threads, self._workers)
        for name in names:
            worker = _GroupSearchWorker(self.session, name)
            thread, worker = workers.run_worker(worker, on_finished=self._on_group_resolved)
            self._threads.append(thread)
            self._workers.append(worker)

    def _detected_list_item_for(self, name):
        for i in range(self.detected_list.count()):
            item = self.detected_list.item(i)
            if item.data(Qt.UserRole) == name:
                return item
        return None

    def _refresh_detected_list_item(self, name):
        """Updates one row in the detected-names list to show its current
        resolution status and whether it's the active search target -
        called whenever a name resolves, or whenever the active target
        changes, so the list always reflects reality rather than the
        static plain-text-only list this used to be."""
        item = self._detected_list_item_for(name)
        if item is None:
            return
        if name in self._name_to_group:
            status = f"✓ {name}  →  {self._name_to_group[name]['name']}"
        elif self._pending_resolutions > 0 and name not in self._name_to_group:
            status = f"⏳ {name}  (searching…)"
        else:
            status = f"⚠ {name}  (unresolved — click to search a match)"
        if name == self._active_target_name:
            status += "   ← searching for this"
        item.setText(status)

    def _update_search_target_label(self):
        if self._active_target_name:
            self.search_target_label.setText(
                f"Searching for a match for '{self._active_target_name}'. "
                f"Double-click a result below to resolve it."
            )
            self.search_target_label.setStyleSheet(f"color: {Color.ACCENT};")
        else:
            self.search_target_label.setText(
                "No specific tag selected — search below to pick a fallback group "
                "for the whole upload, or click an unresolved name above to target it."
            )
            self.search_target_label.setStyleSheet(f"color: {Color.TEXT_SECONDARY};")

    def _on_detected_name_clicked(self, item):
        name = item.data(Qt.UserRole)
        if not name:
            return
        self._active_target_name = name
        self._update_search_target_label()
        self._render_search_results_for_active_target()
        self.search_input.setFocus()

    def _on_group_resolved(self, name, results, matched_query):
        self._pending_resolutions -= 1

        match = parser_mod.auto_match_group(name, results, matched_query=matched_query)
        if match:
            self._name_to_group[name] = match
        else:
            # Stash the candidates (possibly empty) against this specific
            # name instead of writing them straight into the shared
            # search_results_list - that widget is shared across every
            # unresolved name, so writing directly here meant multiple
            # names' candidate lists ended up stacked together with no
            # way to tell which belonged to which. _render_search_results
            # displays only the active target's candidates.
            self._auto_candidates[name] = results

        self._refresh_detected_list_item(name)

        if self._pending_resolutions == 0:
            self._finalize_auto_detection()
            if self._active_target_name is None:
                first_unresolved = next(
                    (n for n in self._detected_names if n not in self._name_to_group), None
                )
                if first_unresolved:
                    self._active_target_name = first_unresolved
                    self._update_search_target_label()
                    self._render_search_results_for_active_target()

    def _render_search_results_for_active_target(self):
        """Shows the auto-search candidates (if any) for whichever name
        is currently the active search target - and only that name's
        candidates, never another name's leftover results."""
        self.search_results_list.clear()
        name = self._active_target_name
        if not name:
            return
        if name in self._name_to_group:
            resolved = self._name_to_group[name]
            self.search_results_list.addItem(
                QListWidgetItem(f"✓ '{name}' is already resolved to {resolved['name']} (ID: {resolved['id']}).")
            )
            self.search_results_list.addItem(
                QListWidgetItem("Search below to change it, or click a different unresolved name above.")
            )
            return
        candidates = self._auto_candidates.get(name)
        if candidates:
            self.search_results_list.addItem(QListWidgetItem(f"— Pick a match for '{name}': —"))
            for g in candidates:
                item = QListWidgetItem(f"{g['name']} (ID: {g['id']})")
                item.setData(Qt.UserRole, (name, g))
                self.search_results_list.addItem(item)
        elif name in self._auto_candidates:
            # We searched and got nothing back at all.
            self.search_results_list.addItem(
                QListWidgetItem(f"No exact match found for '{name}' automatically — "
                                 f"search below, or enter its numeric ID above.")
            )

    def _finalize_auto_detection(self):
        if not self._name_to_group:
            return  

        is_mixed = parser_mod.is_groups_mixed(self._per_file_names)

        if is_mixed:
            self._per_file_group_map_result = parser_mod.resolve_per_file_group_ids(
                self._per_file_names, self._name_to_group
            )
            self._strip_bracket_groups = True
            
            # Explicitly set mixed name for UI
            self._resolved_group_name = "Multiple / Auto-Detected"
            self.selected_group_label.setText(
                "Auto-resolved: " + ", ".join(f"{n} → {g['name']}" for n, g in self._name_to_group.items())
            )
        else:
            self._resolved_group_ids = [g["id"] for g in self._name_to_group.values()]
            self._resolved_group_name = ", ".join(g["name"] for g in self._name_to_group.values())
            self._strip_bracket_groups = True
            self._mark_group_selected(self._resolved_group_name)

    def _on_manual_search(self):
        query = self.search_input.text().strip()
        if not query:
            return
        if query.isdigit():
            self._apply_group_choice_to_target({"id": int(query), "name": f"ID: {query}"})
            return

        # Capture which name this search is actually for, right now -
        # not whatever happens to be active later when the (async)
        # result arrives. See _on_manual_search_finished for why this
        # matters.
        search_target = self._active_target_name

        self.search_results_list.clear()
        self.search_results_list.addItem(QListWidgetItem(f"Searching for '{query}'…"))
        self.search_button.setEnabled(False)

        worker = _ManualSearchWorker(self.session, query)
        workers.prune_finished(self._threads, self._workers)
        thread, worker = workers.run_worker(
            worker,
            on_finished=lambda q, results: self._on_manual_search_finished(q, results, search_target),
        )
        self._threads.append(thread)
        self._workers.append(worker)

    def _on_manual_search_finished(self, query, results, search_target):
        """search_target is whichever name was active when this search
        was launched (see _on_manual_search) - deliberately NOT
        self._active_target_name, which may have changed while the
        search was in flight (the user clicked a different detected
        name, or picked a match for another one) while waiting on this
        one. Without pinning it, results for e.g. 'LostNerevarine-Empire'
        could silently render as if they were for whatever name the user
        had since clicked on instead - or worse, get attributed to that
        other name if picked, resolving the wrong tag.
        """
        self.search_button.setEnabled(True)

        if search_target != self._active_target_name:
            # The user moved on to a different name while this search
            # was running. Don't touch the results list they're
            # currently looking at (it belongs to the new active
            # target) - but don't just silently drop this search either,
            # since as far as the user's concerned they asked for it and
            # deserve to see it happened. Recording it here means
            # switching back to search_target re-shows these results
            # instead of "no exact match" / an empty list.
            if results:
                self._auto_candidates[search_target] = results
                self._refresh_detected_list_item(search_target)
            return

        self.search_results_list.clear()
        if not results:
            msg = f"No groups found for '{query}'. Try a different spelling, or enter the group's numeric ID above instead."
            self.search_results_list.addItem(QListWidgetItem(msg))
            return
        if search_target:
            self.search_results_list.addItem(
                QListWidgetItem(f"— Pick a match for '{search_target}': —")
            )
        for g in results:
            item = QListWidgetItem(f"{g['name']} (ID: {g['id']})")
            item.setData(Qt.UserRole, (search_target, g))
            self.search_results_list.addItem(item)

    def _on_search_result_picked(self, item):
        data = item.data(Qt.UserRole)
        if not data:
            return
        target_name, group = data
        self._apply_group_choice_to_target(group, target_name=target_name)

    def _apply_group_choice_to_target(self, group, target_name=None):
        """Records `group` as the resolution for `target_name` if given
        (or self._active_target_name if not), or as the whole-batch
        fallback group if there's genuinely no active target.

        This is the single place that decides "does this pick resolve
        one specific detected bracket-tag name, or does it set the
        uniform group for every file with no per-tag match" - previously
        that decision lived duplicated (and inconsistently) across the
        numeric-ID shortcut and the search-result-click handler, and
        neither of them ever considered which name the user had actually
        selected to search for, which is why picking a manual search
        result never resolved the specific unresolved tag it was meant
        to.
        """
        name = target_name if target_name is not None else self._active_target_name
        if name:
            self._name_to_group[name] = group
            self._refresh_detected_list_item(name)
            self._finalize_auto_detection()
            next_unresolved = next(
                (n for n in self._detected_names if n not in self._name_to_group), None
            )
            self._active_target_name = next_unresolved
            self._update_search_target_label()
            self._render_search_results_for_active_target()
            self.search_input.clear()
        else:
            self._resolved_group_ids = [group["id"]]
            self._resolved_group_name = group["name"]
            self._mark_group_selected(group["name"])

    def _unresolved_group_detections(self):
        """Returns (unresolved_names, affected_filepaths) for bracket-tag
        names that were detected in filenames but never matched to an
        actual group - either because the search found nothing, or
        because the search found candidates but the user never picked
        one from the results list.

        This exists because the old Continue-button check
        (`not self._resolved_group_ids and not any(self._per_file_group_map_result.values())`)
        only caught the case where NO group was resolved at all. It
        missed the more common edge case: a chapter/volume batch with
        multiple different bracket tags (e.g. some files tagged
        [GroupA], others [UnknownGroup]) where GroupA resolves fine but
        UnknownGroup doesn't - resolve_per_file_group_ids() silently
        drops any file whose tag never resolved, so those files would
        upload with no group and no warning at all.
        """
        if not self._per_file_names:
            return [], []

        unresolved_names = sorted({
            name
            for names in self._per_file_names.values()
            for name in names
            if name not in self._name_to_group
        }, key=str.lower)

        if not unresolved_names:
            return [], []

        unresolved_set = {n.lower() for n in unresolved_names}
        affected_files = sorted(
            filepath for filepath, names in self._per_file_names.items()
            if any(n.lower() in unresolved_set for n in names)
        )
        return unresolved_names, affected_files

    def _on_continue(self):
        if self.individual_radio.isChecked():
            scanlator_name = self.scanlator_input.text().strip()
            if not scanlator_name:
                QMessageBox.warning(self, "Missing name", "Please enter your scanlator name.")
                return
            self.config_finished.emit({
                "is_group_upload": False,
                "group_ids": [],
                "scanlator_name": scanlator_name,
                "per_file_group_map": {},
                "strip_bracket_groups": False,
                "group_name": scanlator_name, 
            })
            return

        if not self._resolved_group_ids and not any(self._per_file_group_map_result.values()):
            QMessageBox.warning(
                self, "No group selected",
                "Please search for and select a group (or enter its ID) before continuing."
            )
            return

        unresolved_names, affected_files = self._unresolved_group_detections()
        if unresolved_names:
            file_list = "\n".join(f"  • {os.path.basename(p)}" for p in affected_files[:10])
            if len(affected_files) > 10:
                file_list += f"\n  … and {len(affected_files) - 10} more"
            names_str = ", ".join(f"'{n}'" for n in unresolved_names)

            msg = QMessageBox(self)
            msg.setIcon(QMessageBox.Warning)
            msg.setWindowTitle("Unresolved group tag(s)")
            msg.setText(
                f"{names_str} {'was' if len(unresolved_names) == 1 else 'were'} found in filenames but "
                f"could not be matched to a group on the site.\n\n"
                f"{len(affected_files)} file(s) will upload with NO group attribution if you continue:\n"
                f"{file_list}"
            )
            msg.setInformativeText("Go back and search/select a match for the unresolved tag(s), or continue anyway?")
            go_back_btn = msg.addButton("Go back and resolve", QMessageBox.RejectRole)
            msg.addButton("Continue without group", QMessageBox.AcceptRole)
            msg.setDefaultButton(go_back_btn)
            msg.exec()
            if msg.clickedButton() == go_back_btn:
                return

        self.config_finished.emit({
            "is_group_upload": True,
            "group_ids": self._resolved_group_ids,
            "scanlator_name": None,
            "per_file_group_map": self._per_file_group_map_result,
            "strip_bracket_groups": self._strip_bracket_groups,
            "group_name": self._resolved_group_name, 
        })

    def stop_background_work(self):
        for thread in self._threads:
            if thread_is_running(thread):
                thread.quit()
                thread.wait(2000)